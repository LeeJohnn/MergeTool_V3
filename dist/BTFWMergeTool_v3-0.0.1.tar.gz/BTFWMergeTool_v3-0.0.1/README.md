Requirements:
    argparse
    struct
    datetime
    logging
    os
    struct
    toml

Example: default_config.toml

Usage:
    python __init__.py --toml_file_path [TOML_FILE]
    =>  ex. python __init__.py --toml_file_path TomlFile/default_config.toml

Output:
    Export/bt_fw_asic_rom_patch_YYYYMMDD_HHMMSS.bin
    Export/bt_fw_asic_rom_patch_YYYYMMDD_HHMMSS.log
